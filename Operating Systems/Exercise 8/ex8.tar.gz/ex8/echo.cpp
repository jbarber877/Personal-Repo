#include<iostream>
#include<stdlib.h>
#include <sys/socket.h>
#include<cstring>
#include<netinet/in.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<stack>
#include<queue>


using namespace std;
queue<string> q;
queue<string> s;

string display(){
    string display = "Wall Contents\r\n -------------\r\n";

    if (! q.size() > 0){
	display+= "[NO MESSAGES - WALL EMPTY]\r\n\r\n";
        return display;
    }

    while (!q.empty()){
	s.push(q.front());
	string f = q.front(); // why?
	display+= f;
	display+= "\r\n";
	q.pop();
    }

    while (!s.empty()){
	q.push(s.front());
	s.pop();
    }
    display+="\r\n";
    return display;
}

void clear(){
    while (!q.empty()){
	q.pop();
    }
}

int main (int argc, char** argv){
    int qsize = 20;
    int port = 5514;

    if (argc == 3){
        qsize = atoi(argv[1]);
        port = atoi(argv[2]);
    }
    if (argc == 2){
        qsize = atoi(argv[1]);
    }

    // socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);

    // bind
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);

    int bind_value = bind(sock, (struct sockaddr*)&address, sizeof(address));
    if (bind_value < 0){
        perror("Could not bind");
        return 1;
    }

    // listen
    int listen_value = listen(sock, 1);
    if (listen_value < 0){
        perror("Could not listen");
        return 1;
    }

    // accept
    struct sockaddr_in remote_address;
    memset(&remote_address, 0, sizeof(remote_address));
    socklen_t remote_addrlen = sizeof(address);

    int client_socket = accept(sock, (struct sockaddr*)&remote_address, &remote_addrlen);
    if(client_socket < 0){
        perror("Could not accept");
        return 1;
    }

    std::string client_ip = inet_ntoa(remote_address.sin_addr);
    int remote_port = ntohs(remote_address.sin_port);

    int bufflen = 1024;
    char buffer[bufflen];

    cout << "Wall server running on port " << port << " with queue size " << qsize << endl;
    string d = display();
    if(send(client_socket, d.c_str(), d.length(), 0) < 0){return 1;}
    string persist = "";

    while (1){

	if(persist == "quit"){
	    string foo = display();
	    send(client_socket, foo.c_str(), foo.length(), 0);
	}

	memset(buffer, '\n', bufflen*sizeof(buffer[0]));

	string res = "Enter a command: ";
	if(send(client_socket, res.c_str(), res.length(), 0)<0){
	    return 1;
	}

        // recv
        int bytes_recieved = recv(client_socket, buffer, bufflen-1, 0);
        if (bytes_recieved < 0){
            perror("Could not recieve");
            return 1;
        }

        if (buffer[bytes_recieved-1] == '\n'){
            buffer[bytes_recieved] = 0;
        }

	// convert buffer to a command
	string cmd = "";
	for (int i = 0; i < strlen(buffer); i++){//anticipation
	    if(buffer[i] == '\n')
		continue;
	    else
	        cmd+= buffer[i];
	    }

	memset(buffer, '\n', bufflen*sizeof(buffer[0]));
	if(cmd == "post"){
	    res = "Enter name: ";
	    if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}

	    int maxLength = 80;
	    string temp = "";

	    int post_msg = recv(client_socket, buffer, bufflen-1, 0);
	    if(post_msg < 0){perror("Could not recieve"); return 1;}

	    for(int i = 0; i < strlen(buffer); i++){
		if(buffer[i] == '\n')
		    continue;
		else
		    temp += buffer[i];
	    }

	    temp += ": ";
	    int len = maxLength -strlen(buffer) -2;
	    res = "Post [Max length " + to_string(80 - temp.length()) + "]: ";
	    if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}

	    memset(buffer, '\n', bufflen*sizeof(buffer[0]));
	    post_msg = recv(client_socket, buffer, bufflen-1, 0);
	    if(post_msg < 0){perror("Could not recieve"); return 1;}

	    for(int i = 0; i < strlen(buffer); i++){
		if (buffer[i] == '\n' || buffer[i] == '0')
		    continue;
		else
		    temp += buffer[i];
	    }

	    if (temp.length() > maxLength){
		res = "Error: message is too long!\r\n\r\n";
		if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}
	    } else {
		if(q.size() == qsize)
		    q.pop();
		q.push(temp);
		res = "Successfully tagged the wall.\r\n\r\n";
		if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}
	    }

	    string d = display();
	    if(send(client_socket, d.c_str(), d.length(), 0) < 0){return 1;}
	}

	if(cmd == "clear"){
	    clear();
	    res = "Wall cleared.\r\n\r\n";
	    if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}
	    string d = display();
	    if(send(client_socket, d.c_str(), d.length(), 0) < 0){return 1;}
	    continue;
	}

	if(cmd == "kill"){
	    res = "Closing socket and terminating server. Bye!";
	    if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}
	    shutdown(client_socket, SHUT_RDWR);
	    return 0;
	}

	if(cmd == "quit"){
	    res = "Come back soon. Bye!";
	    if(send(client_socket, res.c_str(), res.length(), 0) < 0){return 1;}
	    persist = "quit";
	    close(client_socket);
	    client_socket = accept(sock, (struct sockaddr*)&remote_address, &remote_addrlen);
	    continue;
	} else {persist = "false";}
    }// end while

    return 0;
}
